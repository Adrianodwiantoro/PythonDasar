x = "john"

x = 'john'

a = 4 
A = "Sally"

print(x)
print(a)
print(A)