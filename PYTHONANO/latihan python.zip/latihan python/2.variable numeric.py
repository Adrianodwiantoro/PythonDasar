w = 3

x = str(3)
y = int(3)
z = float(3)

print(w)
print(y)
print(z)