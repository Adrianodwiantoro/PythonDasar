x = 1
while x <=5:
    print(x)
    x += 1
    if x == 4:
        break