import PySimpleGUI as sg

sg.Window(tittle="Hello World", layout=[[]], margins=(100, 50)).read()