x = 10
if x> 10:
    print("x lebih besar dari 10")
elif x< 10:
    print("x lebih kecil dari 10")
else:
    print("x tidak boleh lebih besar dari 10")