def my_function(fname):
    print(fname + " Refanes")

my_function("Emil")
my_function("Tobias")
my_function("Linnus")