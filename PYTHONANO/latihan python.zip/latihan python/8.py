X = 5 == 5
Y = 1 > 2

print('X and Y is',X and Y)

print('X or Y is',X or Y)

print('not X is',not X)