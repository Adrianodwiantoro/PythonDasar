class MyClass:
    x = 5

p1 = MyClass()

print(p1.x)