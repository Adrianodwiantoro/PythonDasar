for i in range(100):
    print("Saya tidak akan mengulangi perbuatan itu lagi")